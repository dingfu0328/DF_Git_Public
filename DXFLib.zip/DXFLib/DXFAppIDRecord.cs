namespace DXFLib
{
	public class DXFAppIDRecord : DXFRecord
	{
		public string ApplicationName
		{
			get;
			set;
		}
	}
}
