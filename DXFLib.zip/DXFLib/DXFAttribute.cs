namespace DXFLib
{
	[Entity("ATTRIB")]
	public class DXFAttribute : DXFGenericEntity
	{
	}
}
