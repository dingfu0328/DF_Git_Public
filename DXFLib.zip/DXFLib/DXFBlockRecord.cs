namespace DXFLib
{
	public class DXFBlockRecord : DXFRecord
	{
		public string BlockName
		{
			get;
			set;
		}
	}
}
