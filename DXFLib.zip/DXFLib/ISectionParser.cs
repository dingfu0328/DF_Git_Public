namespace DXFLib
{
	internal interface ISectionParser
	{
		void ParseGroupCode(DXFDocument doc, int groupcode, string value);
	}
}
