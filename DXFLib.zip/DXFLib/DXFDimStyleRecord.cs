namespace DXFLib
{
	public class DXFDimStyleRecord : DXFRecord
	{
		public string StyleName
		{
			get;
			set;
		}
	}
}
