namespace DXFLib
{
	public class DXFVPortRecord : DXFRecord
	{
		private DXFPoint lowerleft = new DXFPoint();

		private DXFPoint upperright = new DXFPoint();

		private DXFPoint center = new DXFPoint();

		private DXFPoint snapbase = new DXFPoint();

		private DXFPoint snapspacing = new DXFPoint();

		private DXFPoint gridspacing = new DXFPoint();

		private DXFPoint direction = new DXFPoint();

		private DXFPoint target = new DXFPoint();

		public string VPortName
		{
			get;
			set;
		}

		public DXFPoint LowerLeftCorner => lowerleft;

		public DXFPoint UpperRightCorner => upperright;

		public DXFPoint Center => center;

		public DXFPoint SnapBase => snapbase;

		public DXFPoint SnapSpacing => snapspacing;

		public DXFPoint GridSpacing => gridspacing;

		public DXFPoint Direction => direction;

		public DXFPoint Target => target;

		public double Height
		{
			get;
			set;
		}

		public double AspectRatio
		{
			get;
			set;
		}

		public double LensLength
		{
			get;
			set;
		}

		public double FrontClippingPlane
		{
			get;
			set;
		}

		public double BackClippingPlane
		{
			get;
			set;
		}

		public double SnapRotationAngle
		{
			get;
			set;
		}

		public double TwistAngle
		{
			get;
			set;
		}

		public int ViewMode
		{
			get;
			set;
		}

		public int CircleZoomPercent
		{
			get;
			set;
		}

		public int FastZoomSetting
		{
			get;
			set;
		}

		public int UCSICONSetting
		{
			get;
			set;
		}

		public int SnapEnabled
		{
			get;
			set;
		}

		public int GridEnabled
		{
			get;
			set;
		}

		public int SnapStyle
		{
			get;
			set;
		}

		public int SnapIsoPair
		{
			get;
			set;
		}
	}
}
