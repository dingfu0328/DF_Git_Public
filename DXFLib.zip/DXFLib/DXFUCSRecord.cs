namespace DXFLib
{
	public class DXFUCSRecord : DXFRecord
	{
		private DXFPoint origin = new DXFPoint();

		private DXFPoint xaxis = new DXFPoint();

		private DXFPoint yaxis = new DXFPoint();

		public string UCSName
		{
			get;
			set;
		}

		public DXFPoint Origin => origin;

		public DXFPoint XAxis => xaxis;

		public DXFPoint YAxis => yaxis;
	}
}
