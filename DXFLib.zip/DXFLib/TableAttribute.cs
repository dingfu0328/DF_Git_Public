using System;

namespace DXFLib
{
	[AttributeUsage(AttributeTargets.Property)]
	internal class TableAttribute : Attribute
	{
		public string TableName;

		public Type TableParser;

		public TableAttribute(string name, Type parser)
		{
			TableName = name;
			TableParser = parser;
		}
	}
}
