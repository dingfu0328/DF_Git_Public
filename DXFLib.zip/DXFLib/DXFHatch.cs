namespace DXFLib
{
	[Entity("HATCH")]
	public class DXFHatch : DXFGenericEntity
	{
	}
}
