using System.Collections.Generic;

namespace DXFLib
{
	public class DXFTables
	{
		private List<DXFAppIDRecord> appids = new List<DXFAppIDRecord>();

		private List<DXFBlockRecord> blocks = new List<DXFBlockRecord>();

		private List<DXFDimStyleRecord> dimstyles = new List<DXFDimStyleRecord>();

		private List<DXFLayerRecord> layers = new List<DXFLayerRecord>();

		private List<DXFLineTypeRecord> linetypes = new List<DXFLineTypeRecord>();

		private List<DXFStyleRecord> styles = new List<DXFStyleRecord>();

		private List<DXFUCSRecord> ucs = new List<DXFUCSRecord>();

		private List<DXFViewRecord> views = new List<DXFViewRecord>();

		private List<DXFVPortRecord> vports = new List<DXFVPortRecord>();

		[Table("APPID", typeof(DXFAppIDParser))]
		public List<DXFAppIDRecord> AppIDs => appids;

		[Table("BLOCK_RECORD", typeof(DXFBlockRecordParser))]
		public List<DXFBlockRecord> Blocks => blocks;

		[Table("DIMSTYLE", typeof(DXFDimStyleRecordParser))]
		public List<DXFDimStyleRecord> DimStyles => dimstyles;

		[Table("LAYER", typeof(DXFLayerRecordParser))]
		public List<DXFLayerRecord> Layers => layers;

		[Table("LTYPE", typeof(DXFLineTypeRecordParser))]
		public List<DXFLineTypeRecord> LineTypes => linetypes;

		[Table("STYLE", typeof(DXFStyleRecordParser))]
		public List<DXFStyleRecord> Styles => styles;

		[Table("UCS", typeof(DXFUCSRecordParser))]
		public List<DXFUCSRecord> UCS => ucs;

		[Table("VIEW", typeof(DXFViewRecordParser))]
		public List<DXFViewRecord> Views => views;

		[Table("VPORT", typeof(DXFVPortRecordParser))]
		public List<DXFVPortRecord> VPorts => vports;
	}
}
