namespace DXFLib
{
	[Entity("VIEWPORT")]
	public class DXFViewPort : DXFGenericEntity
	{
	}
}
