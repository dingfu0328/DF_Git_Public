namespace DXFLib
{
	[Entity("XLINE")]
	public class DXFXLine : DXFRay
	{
	}
}
