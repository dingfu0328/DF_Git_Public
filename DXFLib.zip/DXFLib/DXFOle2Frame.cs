namespace DXFLib
{
	[Entity("OLE2FRAME")]
	public class DXFOle2Frame : DXFGenericEntity
	{
	}
}
