using System;
using System.Collections.Generic;
using System.Reflection;

namespace DXFLib
{
	internal class TableParser : ISectionParser
	{
		private Dictionary<string, ISectionParser> tablehandlers = new Dictionary<string, ISectionParser>();

		private ISectionParser currentParser;

		private bool waitingtableheader;

		private bool ignoretable;

		private bool firstrecordfound;

		public void ParseGroupCode(DXFDocument doc, int groupcode, string value)
		{
			if (tablehandlers.Count == 0)
			{
				PropertyInfo[] properties = doc.Tables.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
				for (int i = 0; i < properties.Length; i++)
				{
					object[] customAttributes = properties[i].GetCustomAttributes(inherit: true);
					for (int j = 0; j < customAttributes.Length; j++)
					{
						TableAttribute tableAttribute = customAttributes[j] as TableAttribute;
						if (tableAttribute != null)
						{
							tablehandlers[tableAttribute.TableName] = (ISectionParser)Activator.CreateInstance(tableAttribute.TableParser);
						}
					}
				}
			}
			if (currentParser == null)
			{
				if (groupcode == 0 && value.Trim() == "TABLE")
				{
					waitingtableheader = true;
				}
				else if (waitingtableheader && groupcode == 2 && !ignoretable)
				{
					if (tablehandlers.ContainsKey(value.Trim()))
					{
						currentParser = tablehandlers[value.Trim()];
						waitingtableheader = false;
						ignoretable = false;
						firstrecordfound = false;
					}
					else
					{
						ignoretable = true;
					}
				}
				else if (waitingtableheader && groupcode == 0 && value.Trim() == "ENDTAB")
				{
					waitingtableheader = false;
					ignoretable = false;
				}
			}
			else if (groupcode == 0 && value.Trim() == "ENDTAB")
			{
				currentParser = null;
			}
			else
			{
				if (groupcode == 0)
				{
					firstrecordfound = true;
				}
				if (firstrecordfound)
				{
					currentParser.ParseGroupCode(doc, groupcode, value);
				}
			}
		}
	}
}
