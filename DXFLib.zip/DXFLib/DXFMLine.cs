namespace DXFLib
{
	[Entity("MLINE")]
	public class DXFMLine : DXFGenericEntity
	{
	}
}
