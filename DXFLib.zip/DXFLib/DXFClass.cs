using System;

namespace DXFLib
{
	public class DXFClass
	{
		[Flags]
		public enum Caps
		{
			NoOperationAllowed = 0x0,
			Erase = 0x1,
			Transform = 0x2,
			ColorChange = 0x4,
			LayerChange = 0x8,
			LineTypeChange = 0x10,
			LineTypeScale = 0x20,
			VisibilityChange = 0x40,
			AllOperationExceptCloning = 0x7F,
			Cloning = 0x80,
			AllOp = 0xFF,
			R13FormatProxy = 0x8000
		}

		public string DXFRecord
		{
			get;
			set;
		}

		public string AppName
		{
			get;
			set;
		}

		public string ClassName
		{
			get;
			set;
		}

		public Caps? ClassProxyCapabilities
		{
			get;
			set;
		}

		public bool? WasProxy
		{
			get;
			set;
		}

		public bool? IsEntity
		{
			get;
			set;
		}
	}
}
