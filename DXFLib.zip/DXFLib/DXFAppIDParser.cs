namespace DXFLib
{
	internal class DXFAppIDParser : DXFRecordParser
	{
		private DXFAppIDRecord _currentRecord;

		protected override DXFRecord currentRecord => _currentRecord;

		public override void ParseGroupCode(DXFDocument doc, int groupcode, string value)
		{
			base.ParseGroupCode(doc, groupcode, value);
			if (groupcode == 2)
			{
				_currentRecord.ApplicationName = value;
			}
		}

		protected override void createRecord(DXFDocument doc)
		{
			_currentRecord = new DXFAppIDRecord();
			doc.Tables.AppIDs.Add(_currentRecord);
		}
	}
}
