namespace DXFLib
{
	[Entity("SOLID")]
	public class DXFSolid : DXFEntity
	{
		private DXFPoint extrusion = new DXFPoint();

		private DXFPoint[] corners = new DXFPoint[4]
		{
			new DXFPoint(),
			new DXFPoint(),
			new DXFPoint(),
			new DXFPoint()
		};

		public DXFPoint ExtrusionDirection => extrusion;

		public DXFPoint[] Corners => corners;

		public override void ParseGroupCode(int groupcode, string value)
		{
			base.ParseGroupCode(groupcode, value);
			if (groupcode >= 10 && groupcode <= 33)
			{
				int num = groupcode % 10;
				switch (groupcode / 10)
				{
				case 1:
					Corners[num].X = double.Parse(value);
					break;
				case 2:
					Corners[num].Y = double.Parse(value);
					break;
				case 3:
					Corners[num].Z = double.Parse(value);
					break;
				}
			}
			switch (groupcode)
			{
			case 210:
				ExtrusionDirection.X = double.Parse(value);
				break;
			case 220:
				ExtrusionDirection.Y = double.Parse(value);
				break;
			case 230:
				ExtrusionDirection.Z = double.Parse(value);
				break;
			}
		}
	}
}
