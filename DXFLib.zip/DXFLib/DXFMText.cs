namespace DXFLib
{
	[Entity("MTEXT")]
	public class DXFMText : DXFGenericEntity
	{
	}
}
