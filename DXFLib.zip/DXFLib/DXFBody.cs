namespace DXFLib
{
	[Entity("BODY")]
	public class DXFBody : DXFGenericEntity
	{
	}
}
