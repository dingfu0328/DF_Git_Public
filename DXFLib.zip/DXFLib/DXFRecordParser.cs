namespace DXFLib
{
	internal abstract class DXFRecordParser : ISectionParser
	{
		protected abstract DXFRecord currentRecord
		{
			get;
		}

		protected abstract void createRecord(DXFDocument doc);

		public virtual void ParseGroupCode(DXFDocument doc, int groupcode, string value)
		{
			switch (groupcode)
			{
			case 0:
				createRecord(doc);
				break;
			case 5:
				currentRecord.Handle = value;
				break;
			case 70:
				currentRecord.Flags = int.Parse(value);
				break;
			case 105:
				currentRecord.DimStyleHandle = value;
				break;
			case 100:
				currentRecord.Classhierarchy.Add(value);
				break;
			}
		}
	}
}
