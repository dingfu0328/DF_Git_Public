using System;

namespace DXFLib
{
	[AttributeUsage(AttributeTargets.Property)]
	internal class HeaderAttribute : Attribute
	{
		public string Name;

		public HeaderAttribute(string varname)
		{
			Name = varname;
		}
	}
}
