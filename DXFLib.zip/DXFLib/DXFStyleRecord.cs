using System;

namespace DXFLib
{
	public class DXFStyleRecord : DXFRecord
	{
		[Flags]
		public enum TextGenerationFlags
		{
			MirrorX = 0x2,
			MirrorY = 0x4
		}

		public string StyleName
		{
			get;
			set;
		}

		public double FixedHeight
		{
			get;
			set;
		}

		public double WidthFactor
		{
			get;
			set;
		}

		public double ObliqueAngle
		{
			get;
			set;
		}

		public TextGenerationFlags GenerationFlags
		{
			get;
			set;
		}

		public double LastUsedHeight
		{
			get;
			set;
		}

		public string FontFileName
		{
			get;
			set;
		}

		public string BigFontFileName
		{
			get;
			set;
		}
	}
}
