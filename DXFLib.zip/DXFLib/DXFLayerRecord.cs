namespace DXFLib
{
	public class DXFLayerRecord : DXFRecord
	{
		public string LayerName
		{
			get;
			set;
		}

		public int Color
		{
			get;
			set;
		}

		public string LineType
		{
			get;
			set;
		}

		public int LineWeight
		{
			get;
			set;
		}
	}
}
