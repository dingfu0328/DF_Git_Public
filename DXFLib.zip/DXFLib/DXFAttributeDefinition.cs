namespace DXFLib
{
	[Entity("ATTDEF")]
	public class DXFAttributeDefinition : DXFGenericEntity
	{
	}
}
