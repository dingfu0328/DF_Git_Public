namespace DXFLib
{
	[Entity("LEADER")]
	public class DXFLeader : DXFGenericEntity
	{
	}
}
