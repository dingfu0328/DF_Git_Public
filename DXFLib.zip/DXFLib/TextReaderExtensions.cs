using System.IO;

namespace DXFLib
{
	public static class TextReaderExtensions
	{
		public static void ReadDXFEntry(this TextReader obj, out int? groupcode, out string value)
		{
			string text = obj.ReadLine();
			int result;
			if (text == null)
			{
				groupcode = null;
				value = null;
			}
			else if (int.TryParse(text.Trim(), out result))
			{
				groupcode = result;
				value = obj.ReadLine();
			}
			else
			{
				value = null;
				groupcode = null;
			}
		}
	}
}
