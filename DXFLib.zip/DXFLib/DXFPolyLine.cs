using System;

namespace DXFLib
{
	[Entity("POLYLINE")]
	public class DXFPolyLine : DXFEntity
	{
		[Flags]
		public enum FlagsEnum
		{
			closed = 0x1,
			CurveFitVerticesAdded = 0x2,
			SplineFitVerticesAdded = 0x4,
			Is3DPolyLine = 0x8,
			Is3DPolyMesh = 0x10,
			MeshIsClosed = 0x20,
			IsPolyFace = 0x40,
			LineTypePatternContinous = 0x80
		}

		private DXFPoint extrusion = new DXFPoint();

		public double Elevation
		{
			get;
			set;
		}

		public double Thickness
		{
			get;
			set;
		}

		public FlagsEnum Flags
		{
			get;
			set;
		}

		public double DefaultStartWidth
		{
			get;
			set;
		}

		public double DefaultEndWidth
		{
			get;
			set;
		}

		public int MVertexCount
		{
			get;
			set;
		}

		public int NVertexCount
		{
			get;
			set;
		}

		public int SurfaceMDensity
		{
			get;
			set;
		}

		public int SurfaceNDensity
		{
			get;
			set;
		}

		public int CurvesAndSmoothSurfaceType
		{
			get;
			set;
		}

		public DXFPoint ExtrusionDirection => extrusion;

		public override bool HasChildren => true;

		public override void ParseGroupCode(int groupcode, string value)
		{
			base.ParseGroupCode(groupcode, value);
			switch (groupcode)
			{
			case 30:
				Elevation = double.Parse(value);
				break;
			case 39:
				Thickness = double.Parse(value);
				break;
			case 70:
				Flags = (FlagsEnum)Enum.Parse(typeof(FlagsEnum), value);
				break;
			case 40:
				DefaultStartWidth = double.Parse(value);
				break;
			case 41:
				DefaultEndWidth = double.Parse(value);
				break;
			case 71:
				MVertexCount = int.Parse(value);
				break;
			case 72:
				NVertexCount = int.Parse(value);
				break;
			case 73:
				SurfaceMDensity = int.Parse(value);
				break;
			case 74:
				SurfaceNDensity = int.Parse(value);
				break;
			case 75:
				CurvesAndSmoothSurfaceType = int.Parse(value);
				break;
			case 210:
				ExtrusionDirection.X = double.Parse(value);
				break;
			case 220:
				ExtrusionDirection.Y = double.Parse(value);
				break;
			case 230:
				ExtrusionDirection.Z = double.Parse(value);
				break;
			}
		}
	}
}
