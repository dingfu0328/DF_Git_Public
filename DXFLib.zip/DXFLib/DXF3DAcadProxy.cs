namespace DXFLib
{
	[Entity("ACAD_PROXY_ENTITY")]
	public class DXF3DAcadProxy : DXFGenericEntity
	{
	}
}
