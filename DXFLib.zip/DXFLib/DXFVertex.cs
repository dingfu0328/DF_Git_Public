using System;

namespace DXFLib
{
	[Entity("VERTEX")]
	public class DXFVertex : DXFEntity
	{
		[Flags]
		public enum FlagsEnum
		{
			IsExtraVertex = 0x1,
			CurveFitTangentDefined = 0x2,
			NotUsed = 0x4,
			SplineVertexCreatedForSplineFitting = 0x8,
			SplineFrameControlPoint = 0x10,
			PolyLineVertex = 0x20,
			PolyLineMesh = 0x40,
			PolyFaceMesh = 0x80
		}

		private DXFPoint location = new DXFPoint();

		private int[] indices = new int[4];

		public DXFPoint Location => location;

		public double StartWidth
		{
			get;
			set;
		}

		public double EndWidth
		{
			get;
			set;
		}

		public double Buldge
		{
			get;
			set;
		}

		public FlagsEnum Flags
		{
			get;
			set;
		}

		public int[] PolyfaceIndices => indices;

		public double CurveFitTangentDirection
		{
			get;
			set;
		}

		public override void ParseGroupCode(int groupcode, string value)
		{
			base.ParseGroupCode(groupcode, value);
			switch (groupcode)
			{
			case 10:
				Location.X = double.Parse(value);
				break;
			case 20:
				Location.Y = double.Parse(value);
				break;
			case 30:
				Location.Z = double.Parse(value);
				break;
			case 40:
				StartWidth = double.Parse(value);
				break;
			case 41:
				EndWidth = double.Parse(value);
				break;
			case 42:
				Buldge = double.Parse(value);
				break;
			case 70:
				Flags = (FlagsEnum)Enum.Parse(typeof(FlagsEnum), value);
				break;
			case 50:
				CurveFitTangentDirection = double.Parse(value);
				break;
			case 71:
			case 72:
			case 73:
			case 74:
			{
				int num = groupcode % 10;
				num--;
				PolyfaceIndices[num] = int.Parse(value);
				break;
			}
			}
		}
	}
}
