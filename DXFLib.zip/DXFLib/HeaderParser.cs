using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;

namespace DXFLib
{
	internal class HeaderParser : ISectionParser
	{
		private Dictionary<string, PropertyInfo> fields = new Dictionary<string, PropertyInfo>();

		private PropertyInfo currentVar;

		public void ParseGroupCode(DXFDocument doc, int groupcode, string value)
		{
			if (fields.Count == 0)
			{
				PropertyInfo[] properties = doc.Header.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
				foreach (PropertyInfo propertyInfo in properties)
				{
					if (!propertyInfo.CanWrite || !propertyInfo.CanRead)
					{
						continue;
					}
					object[] customAttributes = propertyInfo.GetCustomAttributes(inherit: true);
					for (int j = 0; j < customAttributes.Length; j++)
					{
						HeaderAttribute headerAttribute = customAttributes[j] as HeaderAttribute;
						if (headerAttribute != null)
						{
							fields[headerAttribute.Name] = propertyInfo;
						}
					}
				}
			}
			if (groupcode == 9)
			{
				string key = value.Trim();
				if (fields.ContainsKey(key))
				{
					currentVar = fields[key];
				}
				else
				{
					currentVar = null;
				}
			}
			else
			{
				if (currentVar == null)
				{
					return;
				}
				if (currentVar.PropertyType.Equals(typeof(string)))
				{
					currentVar.SetValue(doc.Header, value, null);
				}
				else if (currentVar.PropertyType.IsGenericType && currentVar.PropertyType.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
				{
					Type type = currentVar.PropertyType.GetGenericArguments()[0];
					if (type.Equals(typeof(int)))
					{
						int? num = ((value.ToLower().Contains('a') || value.ToLower().Contains('b') || value.ToLower().Contains('c') || value.ToLower().Contains('d') || value.ToLower().Contains('e') || value.ToLower().Contains('f')) ? new int?(int.Parse(value, NumberStyles.HexNumber)) : new int?(int.Parse(value, NumberStyles.Any)));
						currentVar.SetValue(doc.Header, num, null);
					}
					else if (type.Equals(typeof(double)))
					{
						double? num2 = double.Parse(value);
						currentVar.SetValue(doc.Header, num2, null);
					}
					else if (type.Equals(typeof(bool)))
					{
						if (new int?(int.Parse(value)) != 0)
						{
							currentVar.SetValue(doc.Header, true, null);
						}
						else
						{
							currentVar.SetValue(doc.Header, false, null);
						}
					}
					else if (type.IsEnum)
					{
						object value2 = Enum.Parse(type, value);
						currentVar.SetValue(doc.Header, value2, null);
					}
				}
				else if (currentVar.PropertyType.Equals(typeof(DXFPoint)))
				{
					DXFPoint dXFPoint = (DXFPoint)currentVar.GetValue(doc.Header, null);
					if (dXFPoint == null)
					{
						dXFPoint = new DXFPoint();
						currentVar.SetValue(doc.Header, dXFPoint, null);
					}
					switch (groupcode)
					{
					case 10:
						dXFPoint.X = double.Parse(value);
						break;
					case 20:
						dXFPoint.Y = double.Parse(value);
						break;
					case 30:
						dXFPoint.Z = double.Parse(value);
						break;
					}
				}
			}
		}
	}
}
