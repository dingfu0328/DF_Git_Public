namespace DXFLib
{
	[Entity("OLEFRAME")]
	public class DXFOleFrame : DXFGenericEntity
	{
	}
}
