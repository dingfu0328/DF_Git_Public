using System;

namespace DXFLib
{
	[Entity("3DFACE")]
	public class DXF3DFace : DXFEntity
	{
		[Flags]
		public enum FlagsEnum
		{
			FirstEdgeInvisible = 0x1,
			SecondEdgeInvisible = 0x2,
			ThirdEdgeInvisible = 0x4,
			FourthEdgeInvisible = 0x8
		}

		private DXFPoint[] corners = new DXFPoint[3]
		{
			new DXFPoint(),
			new DXFPoint(),
			new DXFPoint()
		};

		public DXFPoint[] Corners => corners;

		public FlagsEnum Flags
		{
			get;
			set;
		}

		public override void ParseGroupCode(int groupcode, string value)
		{
			base.ParseGroupCode(groupcode, value);
			if (groupcode >= 10 && groupcode <= 33)
			{
				int num = groupcode % 10;
				switch (groupcode / 10)
				{
				case 1:
					Corners[num].X = double.Parse(value);
					break;
				case 2:
					Corners[num].Y = double.Parse(value);
					break;
				case 3:
					Corners[num].Z = double.Parse(value);
					break;
				}
			}
			else if (groupcode == 70)
			{
				Flags = (FlagsEnum)Enum.Parse(typeof(FlagsEnum), value);
			}
		}
	}
}
