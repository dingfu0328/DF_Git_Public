using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Threading;

namespace DXFLib
{
	public class DXFDocument
	{
		private enum LoadState
		{
			OutsideSection,
			InSection
		}

		private DXFHeader header = new DXFHeader();

		private List<DXFClass> classes = new List<DXFClass>();

		private List<DXFBlock> blocks = new List<DXFBlock>();

		private DXFTables tables = new DXFTables();

		private List<DXFEntity> entities = new List<DXFEntity>();

		public DXFHeader Header => header;

		public List<DXFClass> Classes => classes;

		public List<DXFBlock> Blocks => blocks;

		public DXFTables Tables => tables;

		public List<DXFEntity> Entities => entities;

		public event EventHandler OnFileVersionIncompatible;

		public void Load(string filename)
		{
			FileStream fileStream = new FileStream(filename, FileMode.Open);
			Load(fileStream);
			fileStream.Close();
		}

		public void Load(Stream file)
		{
			CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
			Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-US");
			bool flag = false;
			Dictionary<string, ISectionParser> dictionary = new Dictionary<string, ISectionParser>();
			dictionary["HEADER"] = new HeaderParser();
			dictionary["CLASSES"] = new ClassParser();
			dictionary["TABLES"] = new TableParser();
			dictionary["ENTITIES"] = new EntityParser();
			dictionary["BLOCKS"] = new BlockParser();
			ISectionParser sectionParser = null;
			TextReader obj = new StreamReader(file);
			LoadState loadState = LoadState.OutsideSection;
			obj.ReadDXFEntry(out var groupcode, out var value);
			while (groupcode.HasValue)
			{
				switch (loadState)
				{
				case LoadState.OutsideSection:
					if (groupcode == 0 && value.Trim() == "SECTION")
					{
						loadState = LoadState.InSection;
						obj.ReadDXFEntry(out groupcode, out value);
						if (groupcode != 2)
						{
							throw new Exception("Sektion gefunden aber keinen Namen zur Sektion");
						}
						value = value.Trim();
						if (dictionary.ContainsKey(value))
						{
							sectionParser = dictionary[value];
						}
					}
					break;
				case LoadState.InSection:
					if (groupcode == 0 && value.Trim() == "ENDSEC")
					{
						loadState = LoadState.OutsideSection;
						if (Header.AutoCADVersion == null || !(Header.AutoCADVersion != "AC1014") || flag)
						{
							break;
						}
						try
						{
							if (this.OnFileVersionIncompatible != null)
							{
								this.OnFileVersionIncompatible(this, EventArgs.Empty);
							}
						}
						catch (Exception)
						{
						}
						flag = true;
					}
					else
					{
						sectionParser?.ParseGroupCode(this, groupcode.Value, value);
					}
					break;
				}
				obj.ReadDXFEntry(out groupcode, out value);
			}
			if (loadState == LoadState.InSection)
			{
				throw new Exception("Dateiende erreicht aber immer noch offene Sektion vorhanden");
			}
			Thread.CurrentThread.CurrentCulture = currentCulture;
		}
	}
}
