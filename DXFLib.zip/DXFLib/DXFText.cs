namespace DXFLib
{
	[Entity("TEXT")]
	public class DXFText : DXFGenericEntity
	{
	}
}
