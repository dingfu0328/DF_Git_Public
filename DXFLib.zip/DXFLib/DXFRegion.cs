namespace DXFLib
{
	[Entity("REGION")]
	public class DXFRegion : DXFGenericEntity
	{
	}
}
