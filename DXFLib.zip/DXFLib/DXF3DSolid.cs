namespace DXFLib
{
	[Entity("3DSOLID")]
	public class DXF3DSolid : DXFGenericEntity
	{
	}
}
