using System.Collections.Generic;

namespace DXFLib
{
	public class DXFEntity
	{
		private List<string> classhierarchy = new List<string>();

		private List<DXFEntity> children = new List<DXFEntity>();

		public string EntityType
		{
			get;
			set;
		}

		public string Handle
		{
			get;
			set;
		}

		public List<string> ClassHierarchy => classhierarchy;

		public bool IsInPaperSpace
		{
			get;
			set;
		}

		public string LayerName
		{
			get;
			set;
		}

		public string LineType
		{
			get;
			set;
		}

		public int ColorNumber
		{
			get;
			set;
		}

		public double LineTypeScale
		{
			get;
			set;
		}

		public bool IsInvisible
		{
			get;
			set;
		}

		public int LineWeight
		{
			get;
			set;
		}

		public virtual bool HasChildren => false;

		public List<DXFEntity> Children => children;

		public virtual void ParseGroupCode(int groupcode, string value)
		{
			switch (groupcode)
			{
			case 0:
				EntityType = value;
				break;
			case 5:
				Handle = value;
				break;
			case 100:
				ClassHierarchy.Add(value);
				break;
			case 67:
				IsInPaperSpace = int.Parse(value) == 1;
				break;
			case 8:
				LayerName = value;
				break;
			case 6:
				LineType = value;
				break;
			case 62:
				ColorNumber = int.Parse(value);
				break;
			case 48:
				LineTypeScale = double.Parse(value);
				break;
			case 60:
				IsInvisible = int.Parse(value) == 1;
				break;
			case 370:
				LineWeight = int.Parse(value);
				break;
			}
		}
	}
}
