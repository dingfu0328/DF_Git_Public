using System.Collections.Generic;

namespace DXFLib
{
	public class DXFRecord
	{
		private List<string> classhierarchy = new List<string>();

		public string Handle
		{
			get;
			set;
		}

		public string DimStyleHandle
		{
			get;
			set;
		}

		public List<string> Classhierarchy => classhierarchy;

		public int Flags
		{
			get;
			set;
		}
	}
}
