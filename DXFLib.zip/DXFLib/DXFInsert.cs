namespace DXFLib
{
	[Entity("INSERT")]
	public class DXFInsert : DXFEntity
	{
		private DXFPoint insertionPoint = new DXFPoint();

		private DXFPoint scaling = new DXFPoint();

		private DXFPoint extrusionDirection = new DXFPoint();

		public string BlockName
		{
			get;
			set;
		}

		public DXFPoint InsertionPoint => insertionPoint;

		public DXFPoint Scaling => scaling;

		public double? RotationAngle
		{
			get;
			set;
		}

		public DXFPoint ExtrusionDirection => extrusionDirection;

		public override void ParseGroupCode(int groupcode, string value)
		{
			base.ParseGroupCode(groupcode, value);
			switch (groupcode)
			{
			case 2:
				BlockName = value;
				break;
			case 10:
				InsertionPoint.X = double.Parse(value);
				break;
			case 20:
				InsertionPoint.Y = double.Parse(value);
				break;
			case 30:
				InsertionPoint.Z = double.Parse(value);
				break;
			case 41:
				Scaling.X = double.Parse(value);
				break;
			case 42:
				Scaling.Y = double.Parse(value);
				break;
			case 43:
				Scaling.Z = double.Parse(value);
				break;
			case 50:
				RotationAngle = double.Parse(value);
				break;
			}
		}
	}
}
