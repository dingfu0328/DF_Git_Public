using System;
using System.Collections.Generic;

namespace DXFLib
{
	public class DXFLineTypeRecord : DXFRecord
	{
		[Flags]
		public enum ElementFlags
		{
			None = 0x0,
			AbsoluteRotation = 0x1,
			IsString = 0x2,
			IsShape = 0x4
		}

		public class LineTypeElement
		{
			private List<double> scalings = new List<double>();

			private List<double> xoffsets = new List<double>();

			private List<double> yoffsets = new List<double>();

			public double Length
			{
				get;
				set;
			}

			public ElementFlags Flags
			{
				get;
				set;
			}

			public int? ShapeNumber
			{
				get;
				set;
			}

			public string Shape
			{
				get;
				set;
			}

			public List<double> Scalings => scalings;

			public double? Rotation
			{
				get;
				set;
			}

			public List<double> XOffsets => xoffsets;

			public List<double> YOffsets => yoffsets;

			public string Text
			{
				get;
				set;
			}
		}

		private List<LineTypeElement> elements = new List<LineTypeElement>();

		public string LineTypeName
		{
			get;
			set;
		}

		public string Description
		{
			get;
			set;
		}

		public int AlignmentCode
		{
			get;
			set;
		}

		public List<LineTypeElement> Elements => elements;

		public int ElementCount
		{
			get;
			set;
		}

		public double PatternLength
		{
			get;
			set;
		}
	}
}
