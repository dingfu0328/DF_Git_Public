namespace DXFLib
{
	[Entity("IMAGE")]
	public class DXFImage : DXFGenericEntity
	{
	}
}
