namespace DXFLib
{
	public class DXFViewRecord : DXFRecord
	{
		private DXFPoint center = new DXFPoint();

		private DXFPoint direction = new DXFPoint();

		private DXFPoint target = new DXFPoint();

		public string ViewPortName
		{
			get;
			set;
		}

		public double Height
		{
			get;
			set;
		}

		public double Width
		{
			get;
			set;
		}

		public DXFPoint Center => center;

		public DXFPoint Direction => direction;

		public DXFPoint Target => target;

		public double FrontClippingPlane
		{
			get;
			set;
		}

		public double BackClippingPlane
		{
			get;
			set;
		}

		public double TwistAngle
		{
			get;
			set;
		}

		public double LensLength
		{
			get;
			set;
		}

		public int ViewMode
		{
			get;
			set;
		}
	}
}
