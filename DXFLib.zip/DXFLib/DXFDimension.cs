namespace DXFLib
{
	[Entity("DIMENSION")]
	public class DXFDimension : DXFGenericEntity
	{
	}
}
