using System;

namespace DXFLib
{
	[AttributeUsage(AttributeTargets.Class)]
	internal class EntityAttribute : Attribute
	{
		public string EntityName;

		public EntityAttribute(string Name)
		{
			EntityName = Name;
		}
	}
}
