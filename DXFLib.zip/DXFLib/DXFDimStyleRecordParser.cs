namespace DXFLib
{
	internal class DXFDimStyleRecordParser : DXFRecordParser
	{
		private DXFDimStyleRecord _record;

		protected override DXFRecord currentRecord => _record;

		protected override void createRecord(DXFDocument doc)
		{
			_record = new DXFDimStyleRecord();
			doc.Tables.DimStyles.Add(_record);
		}

		public override void ParseGroupCode(DXFDocument doc, int groupcode, string value)
		{
			base.ParseGroupCode(doc, groupcode, value);
			if (groupcode == 2)
			{
				_record.StyleName = value;
			}
		}
	}
}
