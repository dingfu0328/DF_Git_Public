using System;
using System.Collections.Generic;
using System.Reflection;

namespace DXFLib
{
	internal class EntityParser : ISectionParser
	{
		private Dictionary<string, Type> Entities = new Dictionary<string, Type>();

		private DXFEntity currentEntity;

		private Stack<DXFEntity> stack = new Stack<DXFEntity>();

		public void ParseGroupCode(DXFDocument doc, int groupcode, string value)
		{
			if (Entities.Count == 0)
			{
				Type[] types = Assembly.GetCallingAssembly().GetTypes();
				foreach (Type type in types)
				{
					if (!type.IsClass || type.IsAbstract)
					{
						continue;
					}
					object[] customAttributes = type.GetCustomAttributes(inherit: false);
					for (int j = 0; j < customAttributes.Length; j++)
					{
						EntityAttribute entityAttribute = customAttributes[j] as EntityAttribute;
						if (entityAttribute != null)
						{
							Entities.Add(entityAttribute.EntityName, type);
						}
					}
				}
			}
			if (groupcode == 0)
			{
				if (value == "SEQEND" && stack.Count != 0)
				{
					currentEntity = stack.Pop();
				}
				if (Entities.ContainsKey(value))
				{
					if (currentEntity != null && currentEntity.HasChildren)
					{
						stack.Push(currentEntity);
					}
					currentEntity = Activator.CreateInstance(Entities[value]) as DXFEntity;
					if (stack.Count > 0 && stack.Peek().HasChildren)
					{
						stack.Peek().Children.Add(currentEntity);
					}
					else
					{
						doc.Entities.Add(currentEntity);
					}
				}
				else
				{
					currentEntity = null;
				}
			}
			if (currentEntity != null)
			{
				currentEntity.ParseGroupCode(groupcode, value);
			}
		}
	}
}
